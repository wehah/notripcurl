<div class="footer">
<!-- <p>footer info</p> -->
<?php wp_footer(); ?>
<div class= "aboutCarl"> 
    <h1> About Rip Curl </h1>
    <a href='#'> <p> Information</p> </a>
    <a href='#'><p> Sustainability</p> </a>
</div>
<div class= "help">
    <h1> Help </h1>
    <a href='#'> <p> FAQ</p> </a>
    <a href='#'><p> Return Policy</p> </a>
    <a href='#'><p> Terms & Conditions</p></a>
     </div>
<div class= "socials">
<h1> Rip Curl socials </h1>

<div class="icons">
        <?php
            global $wpdb;
            $table_name = "wp_icons";
            $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY icon_id ASC LIMIT 3, 3", OBJECT);
            

            $themePath = get_template_directory_uri();

            foreach ($results as $icons) {
                echo "<a href='#'>" . file_get_contents(get_template_directory() . '/assets/svg/' . $icons->icon_image) . "</a>";
        }
        ?>

    </div>
</div>



<div class= "newsletter"> 
    <h1> Rip Curl newsletter </h1>

   <a href='#'> <p> Subscribe to our monthly newsletter</p> </a>
</div>

</div>

</html>
