<?php get_header(); ?>



<div class="content">

        <div class="hero"> 
                <?php
                    global $wpdb;
                    $table_name = "wp_products";
                    $product_id = 21;
                    $themePath = get_template_directory_uri();

                    $product = $wpdb->get_row("SELECT * FROM $table_name WHERE product_id= $product_id", OBJECT);

                    if ($product) {
    
                        echo "
                        <div class='info'>
                            <h1> $product->product_name  </h1>
                            <p> $product->product_desc </p>
                            <a href='#' class='iconHero'> <h1> Shop now </h1> </a>
                        </div>
                        <div class='imageHero'>
                            <img src='$themePath/assets/images/$product->product_image'>
                        </div>";
                    } else {
                        echo "Product not found.";
                    }
                ?>
            </div>
        </div>
  

    <h3 class="titleOne">Explore our spring collection  </h3>

    <div class='products'> 
        <?php
            global $wpdb;
            $table_name = "wp_products";
            $results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY product_id LIMIT 4", OBJECT );
            $themePath = get_template_directory_uri();

            //loop
            foreach ( $results as $products ) {
                echo  "
                
                    <div class='product'>
                        <div class='imgCont'> 
                        
                        <a href='#'>  <img src='$themePath/assets/images/$products->product_image'> </a> 
                        
                        </div> 
                        <h1> $products->product_name </h1>
                        <p> $products->product_price </p>
                        </div>

                        
                    ";
            }
        ?>
        </div>
    </div>


    <div class="products2">
        <!-- Products 2 -->
     
        <div class="hero"> 
                <?php
                    global $wpdb;
                    $table_name = "wp_products";
                    $product_id = 22;
                    $themePath = get_template_directory_uri();

                    $product = $wpdb->get_row("SELECT * FROM $table_name WHERE product_id= $product_id", OBJECT);

                    if ($product) {
    
                        echo "
                        <div class='info'>
                            <h1> $product->product_name  </h1>
                            <p> $product->product_desc </p>
                            <a href='#' class='iconHero'> <h1> Shop now </h1> </a>
                        </div>
                        <div class='imageHero'>
                            <img src='$themePath/assets/images/$product->product_image'>  
                        </div>";
                    } else {
                        echo "Product not found.";
                    }
                ?>
            </div>
        </div>

        <h3 class="titleOne">Explore our discounted collection  </h3>

    <div class='products'> 
        <?php
            global $wpdb;
            $table_name = "wp_products";
            $results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY product_id ASC LIMIT 5, 8", OBJECT );
            $themePath = get_template_directory_uri();

            //loop
            foreach ( $results as $products ) {
                echo  "
                
                    <div class='product'>
                        <div class='imgCont'> 
                        <a href='#'>  <img src='$themePath/assets/images/$products->product_image'> </a> 
                        </div> 
                        <h1> $products->product_name </h1>
                        <p> $products->product_price </p>
                        </div>

                        
                    ";
            }
        ?>
        </div>
    </div>



        <!-- Products 2 -->

    </div>

        
        




<?php get_footer(); ?>

</body>

