<html>
<head>
        <!-- <link href="wp-content/themes/superthemeV1/style.css" rel="stylesheet"> -->
        <?php wp_head(); ?> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>



<div class="navbar">
    <div class="logo">
        <h2> RIP CURL</h2>
        <h1 id='receiver'>SURFING COMPANY </h1>   
    </div>

    <div class="links" id="links">
        <?php
            global $wpdb;
            $table_name = "wp_mylinks";
            $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY link_id LIMIT 3", OBJECT);

            $themePath = get_template_directory_uri();

            foreach ($results as $links) {
                // var_dump($links);
                echo "
                <a href='$links->link_link'> <h1 class='target'> $links->link_name</h1></a> 
                ";
            }
        ?>
    </div>

    <div class="icons">
  <?php
        global $wpdb;
        $table_name = "wp_icons";
        $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY icon_id LIMIT 3", OBJECT);

        $themePath = get_template_directory_uri();

        foreach ($results as $icons) {
            echo "<a href='#'>" . file_get_contents(get_template_directory() . '/assets/svg/' . $icons->icon_image) . "</a>";
        }
  ?>
</div>


</div>
<script>
$(document).ready(function() {
    var currentLinkName = ""; 
    

    $(".links h1.target").click(function(e) {
        e.preventDefault(); // 
        var linkName = $(this).text();
        console.log(linkName);

        if (linkName !== currentLinkName) {
            $("#receiver").text(linkName);
            currentLinkName = linkName;
            console.log(linkName)
        }
    });
});
</script>

<body>